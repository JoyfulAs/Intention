import React, {useEffect, useMemo, useState} from 'react';
import {
  Alert, AppState, Pressable, SafeAreaView, ScrollView, StatusBar, StyleSheet,
  Text, View, Switch
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {IntentionNative} from './src/native/IntentionNative';

type Tab = 'Home' | 'Focus' | 'Garden' | 'Settings';
type AppRule = {name: string; packageName: string; enabled: boolean; budget: number};

const C = {
  bg: '#F6F4EC', card: '#FFFEFA', ink: '#26372B', muted: '#778276',
  sage: '#718A72', sageDark: '#405B45', pale: '#E6EBDD',
  line: '#E7E7DC', peach: '#EEDBCB', white: '#FFFFFF'
};

const initialApps: AppRule[] = [
  {name: 'Instagram', packageName: 'com.instagram.android', enabled: true, budget: 10},
  {name: 'TikTok', packageName: 'com.zhiliaoapp.musically', enabled: false, budget: 10},
  {name: 'YouTube', packageName: 'com.google.android.youtube', enabled: false, budget: 20}
];

function Button({title, onPress, secondary = false}: {title: string; onPress: () => void; secondary?: boolean}) {
  return <Pressable onPress={onPress} style={[styles.button, secondary && styles.buttonSecondary]}>
    <Text style={[styles.buttonText, secondary && styles.buttonTextSecondary]}>{title}</Text>
  </Pressable>;
}

function Stat({value, label}: {value: string; label: string}) {
  return <View style={styles.stat}><Text style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></View>;
}

export default function App() {
  const [tab, setTab] = useState<Tab>('Home');
  const [apps, setApps] = useState<AppRule[]>(initialApps);
  const [avoided, setAvoided] = useState(0);
  const [intentional, setIntentional] = useState(0);
  const [focusMinutes, setFocusMinutes] = useState(0);
  const [pauseVisible, setPauseVisible] = useState(false);
  const [remaining, setRemaining] = useState(0);
  const [focusActive, setFocusActive] = useState(false);
  const [focusRemaining, setFocusRemaining] = useState(25 * 60);
  const [monitorEnabled, setMonitorEnabled] = useState(false);
  const [lastPackage, setLastPackage] = useState<string | null>(null);
  const [lastDetectedAt, setLastDetectedAt] = useState(0);

  const refreshMonitor = async () => {
    if (!IntentionNative.available) return;
    try {
      const enabled = await IntentionNative.isMonitorEnabled();
      setMonitorEnabled(enabled);
      const latest = await IntentionNative.getLatestForegroundApp();
      if (latest.packageName) {
        setLastPackage(latest.packageName);
        setLastDetectedAt(latest.timestamp);
      }
    } catch {}
  };

  useEffect(() => {
    refreshMonitor();
    const subscription = IntentionNative.subscribe(event => {
      setLastPackage(event.packageName);
      setLastDetectedAt(event.timestamp);
    });
    const appStateSub = AppState.addEventListener('change', state => {
      if (state === 'active') refreshMonitor();
    });
    return () => { subscription.remove(); appStateSub.remove(); };
  }, []);

  useEffect(() => {
    AsyncStorage.getItem('intention-state').then(raw => {
      if (!raw) return;
      try {
        const s = JSON.parse(raw);
        setApps(s.apps ?? initialApps);
        setAvoided(s.avoided ?? 0);
        setIntentional(s.intentional ?? 0);
        setFocusMinutes(s.focusMinutes ?? 0);
      } catch {}
    });
  }, []);

  useEffect(() => {
    AsyncStorage.setItem('intention-state', JSON.stringify({apps, avoided, intentional, focusMinutes})).catch(() => {});
  }, [apps, avoided, intentional, focusMinutes]);

  useEffect(() => {
    if (!pauseVisible || remaining <= 0) return;
    const timer = setTimeout(() => setRemaining(v => Math.max(0, v - 1)), 1000);
    return () => clearTimeout(timer);
  }, [pauseVisible, remaining]);

  useEffect(() => {
    if (!focusActive) return;
    const timer = setTimeout(() => {
      setFocusRemaining(v => {
        if (v <= 1) {
          setFocusActive(false);
          setFocusMinutes(m => m + 25);
          Alert.alert('Focus complete', 'You made space for what matters. Your garden has grown.');
          return 25 * 60;
        }
        return v - 1;
      });
    }, 1000);
    return () => clearTimeout(timer);
  }, [focusActive, focusRemaining]);

  const openPause = () => { setRemaining(5); setPauseVisible(true); };
  const startFocus = () => { setFocusRemaining(25 * 60); setFocusActive(true); setTab('Focus'); };
  const appLabel = (pkg: string | null) => {
    if (!pkg) return 'No app detected yet';
    return apps.find(a => a.packageName === pkg)?.name ?? pkg;
  };
  const requestMonitorSetup = () => Alert.alert(
    'Enable app detection?',
    'Intention uses Android Accessibility only to detect which app is in the foreground. It does not read screen text, messages, passwords, or keystrokes. Detection is stored locally. You can turn it off anytime in Android Settings.',
    [
      {text: 'Not now', style: 'cancel'},
      {text: 'Continue to settings', onPress: async () => {
        try { await IntentionNative.openAccessibilitySettings(); }
        catch { Alert.alert('Could not open settings', 'Open Android Settings → Accessibility and enable Intention manually.'); }
      }}
    ]
  );
  const fmt = (s: number) => `${Math.floor(s / 60).toString().padStart(2,'0')}:${(s % 60).toString().padStart(2,'0')}`;

  const header = (eyebrow: string, title: string, subtitle?: string) => (
    <View style={styles.header}>
      <Text style={styles.eyebrow}>{eyebrow.toUpperCase()}</Text>
      <Text style={styles.title}>{title}</Text>
      {!!subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
    </View>
  );

  const renderHome = () => <>
    {header('YOUR ATTENTION', 'A little more intentional.', 'Small choices make room for meaningful things.')}
    <View style={styles.gardenCard}>
      <Text style={styles.gardenEyebrow}>YOUR ATTENTION GARDEN</Text>
      <Text style={styles.plant}>🌱</Text>
      <Text style={styles.gardenTitle}>Something is growing.</Text>
      <Text style={styles.gardenSub}>Every intentional choice helps it grow.</Text>
    </View>
    <View style={styles.statsRow}>
      <Stat value={String(intentional)} label="Intentional opens"/>
      <Stat value={String(avoided)} label="Avoided opens"/>
      <Stat value={`${focusMinutes}m`} label="Focus time"/>
    </View>
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Ready for a focus session?</Text>
      <Text style={styles.body}>Give your next 25 minutes a purpose.</Text>
      <Button title="Start a focus session" onPress={startFocus}/>
    </View>
    <View style={styles.card}>
      <Text style={styles.cardTitle}>App detection</Text>
      <Text style={styles.body}>{monitorEnabled ? 'Detection is enabled on this device.' : 'Connect Android app detection to see when selected apps are opened.'}</Text>
      <Text style={styles.note}>Most recently detected: {appLabel(lastPackage)}</Text>
      <Button title={monitorEnabled ? 'Manage detection settings' : 'Set up app detection'} secondary onPress={requestMonitorSetup}/>
    </View>
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Try the pause</Text>
      <Text style={styles.body}>Preview the moment Intention creates before a distracting app.</Text>
      <Button title="Preview intentional pause" secondary onPress={openPause}/>
      <Text style={styles.note}>Preview only. Detection currently records app changes; it does not interrupt or block other apps.</Text>
    </View>
  </>;

  const renderFocus = () => <>
    {header('MAKE SPACE', 'Focus on one thing.', 'A quiet space for the work that matters.')}
    <View style={styles.focusCard}>
      <Text style={styles.focusLabel}>{focusActive ? 'SESSION IN PROGRESS' : 'YOUR NEXT SESSION'}</Text>
      <Text style={styles.focusTimer}>{fmt(focusRemaining)}</Text>
      <Text style={styles.body}>{focusActive ? 'Stay with what you chose.' : 'A gentle 25-minute starting point.'}</Text>
      {focusActive
        ? <Button title="End focus session" onPress={() => {setFocusActive(false); setFocusRemaining(25*60);}} secondary/>
        : <Button title="Begin 25 minutes" onPress={startFocus}/>}
    </View>
    <View style={styles.card}>
      <Text style={styles.cardTitle}>A small intention</Text>
      <Text style={styles.body}>Before you begin, decide what would make this session meaningful.</Text>
    </View>
  </>;

  const renderGarden = () => <>
    {header('YOUR PROGRESS', 'A world that grows with you.', 'No perfect streaks. Just small steps forward.')}
    <View style={styles.gardenCard}>
      <Text style={styles.plant}>🌿</Text>
      <Text style={styles.gardenTitle}>Your first little garden</Text>
      <Text style={styles.gardenSub}>{avoided + intentional} intentional moments recorded</Text>
    </View>
    <View style={styles.statsRow}>
      <Stat value={String(avoided)} label="Pauses chosen"/>
      <Stat value={`${focusMinutes}m`} label="Focused"/>
    </View>
    <View style={styles.card}>
      <Text style={styles.cardTitle}>A gentle reminder</Text>
      <Text style={styles.body}>Progress isn't a streak you can lose. You can begin again whenever you want.</Text>
    </View>
  </>;

  const renderSettings = () => <>
    {header('MAKE IT YOURS', 'Your settings.', 'You stay in control of every intervention.')}
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Android app detection</Text>
      <View style={styles.statusRow}>
        <View style={[styles.statusDot, monitorEnabled && styles.statusDotOn]}/>
        <Text style={styles.body}>{IntentionNative.available ? (monitorEnabled ? 'Accessibility service enabled' : 'Not enabled') : 'Android native module not installed'}</Text>
      </View>
      <Text style={styles.note}>Latest detected app: {appLabel(lastPackage)}{lastDetectedAt ? ` · ${new Date(lastDetectedAt).toLocaleTimeString()}` : ''}</Text>
      <Button title="Open Android Accessibility settings" onPress={requestMonitorSetup}/>
      <Button title="Refresh status" secondary onPress={refreshMonitor}/>
    </View>
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Protected apps</Text>
      {apps.map((a, i) => <View key={a.packageName} style={styles.appRow}>
        <View style={{flex: 1}}>
          <Text style={styles.appName}>{a.name}</Text>
          <Text style={styles.appMeta}>{a.budget} minute daily budget</Text>
        </View>
        <Switch value={a.enabled} onValueChange={v => setApps(old => old.map((x,j) => i === j ? {...x, enabled:v} : x))} trackColor={{true:C.sage}}/>
      </View>)}
      <Text style={styles.note}>Switches save your preferences locally. Detection is separate and currently does not block apps or trigger a pause outside Intention.</Text>
    </View>
    <View style={styles.card}>
      <Text style={styles.cardTitle}>Privacy</Text>
      <Text style={styles.body}>Your demo progress is stored on this device. No account or server is used.</Text>
      <Button title="Reset local demo data" secondary onPress={() => Alert.alert('Reset data?', 'This clears the local demo progress.', [
        {text:'Cancel', style:'cancel'},
        {text:'Reset', style:'destructive', onPress: async () => {setAvoided(0);setIntentional(0);setFocusMinutes(0);setApps(initialApps);await AsyncStorage.removeItem('intention-state');}}
      ])}/>
    </View>
  </>;

  return <SafeAreaView style={styles.safe}>
    <StatusBar barStyle="dark-content" backgroundColor={C.bg}/>
    <View style={styles.topbar}><Text style={styles.brand}>intention<span> </span><Text style={styles.brandDot}>•</Text></Text><Text style={styles.topHint}>OPEN WITH PURPOSE</Text></View>
    <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
      {tab === 'Home' && renderHome()}
      {tab === 'Focus' && renderFocus()}
      {tab === 'Garden' && renderGarden()}
      {tab === 'Settings' && renderSettings()}
    </ScrollView>
    <View style={styles.nav}>
      {(['Home','Focus','Garden','Settings'] as Tab[]).map(t => <Pressable key={t} onPress={() => setTab(t)} style={styles.navItem}>
        <Text style={[styles.navIcon, tab === t && styles.navSelected]}>{({Home:'⌂',Focus:'◷',Garden:'✿',Settings:'⚙'})[t]}</Text>
        <Text style={[styles.navText, tab === t && styles.navSelected]}>{t}</Text>
      </Pressable>)}
    </View>
    {pauseVisible && <View style={styles.modalBackdrop}>
      <View style={styles.pauseCard}>
        <Text style={styles.pauseLeaf}>✿</Text>
        <Text style={styles.eyebrow}>A MOMENT FOR YOURSELF</Text>
        <Text style={styles.pauseTitle}>Take a breath.</Text>
        <Text style={styles.bodyCenter}>What are you hoping to find right now?</Text>
        <Text style={styles.countdown}>{remaining > 0 ? remaining : 'Ready'}</Text>
        <Text style={styles.note}>You can choose to continue. This is your time.</Text>
        <Button title="Open intentionally" onPress={() => {setIntentional(v => v+1);setPauseVisible(false);}}/>
        <Button title="Not now" secondary onPress={() => {setAvoided(v => v+1);setPauseVisible(false);Alert.alert('A choice made with intention', 'Would you like to try reading, journaling, or a short focus session?');}}/>
      </View>
    </View>}
  </SafeAreaView>;
}

const styles = StyleSheet.create({
  safe:{flex:1,backgroundColor:C.bg},
  topbar:{height:54,paddingHorizontal:22,flexDirection:'row',alignItems:'center',justifyContent:'space-between'},
  brand:{fontSize:24,fontWeight:'800',letterSpacing:-1,color:C.ink},
  brandDot:{color:C.sage,fontSize:26},
  topHint:{fontSize:9,fontWeight:'700',letterSpacing:1.5,color:C.muted},
  content:{paddingHorizontal:20,paddingTop:16,paddingBottom:28,gap:16},
  header:{gap:7,marginBottom:4},
  eyebrow:{fontSize:10,fontWeight:'800',letterSpacing:1.7,color:C.sageDark},
  title:{fontSize:29,fontWeight:'700',letterSpacing:-1.1,color:C.ink,lineHeight:35},
  subtitle:{fontSize:14,lineHeight:21,color:C.muted},
  gardenCard:{backgroundColor:C.pale,borderRadius:22,padding:22,alignItems:'center',gap:7},
  gardenEyebrow:{fontSize:9,fontWeight:'800',letterSpacing:1.5,color:C.sageDark},
  plant:{fontSize:66,marginVertical:5},
  gardenTitle:{fontSize:20,fontWeight:'700',color:C.ink},
  gardenSub:{fontSize:12,color:C.muted,textAlign:'center'},
  statsRow:{flexDirection:'row',gap:9},
  stat:{flex:1,backgroundColor:C.card,borderRadius:16,padding:13,borderWidth:1,borderColor:C.line},
  statValue:{fontSize:23,fontWeight:'700',color:C.ink},
  statLabel:{fontSize:10,color:C.muted,marginTop:4},
  card:{backgroundColor:C.card,borderRadius:18,padding:17,borderWidth:1,borderColor:C.line,gap:9},
  cardTitle:{fontSize:16,fontWeight:'700',color:C.ink},
  body:{fontSize:13,lineHeight:20,color:C.muted},
  note:{fontSize:10,lineHeight:15,color:C.muted},
  button:{backgroundColor:C.sageDark,paddingVertical:14,paddingHorizontal:16,borderRadius:13,alignItems:'center',marginTop:4},
  buttonSecondary:{backgroundColor:C.pale},
  buttonText:{fontSize:13,fontWeight:'700',color:C.white},
  buttonTextSecondary:{color:C.sageDark},
  nav:{height:68,borderTopWidth:1,borderTopColor:C.line,backgroundColor:C.card,flexDirection:'row',justifyContent:'space-around',alignItems:'center'},
  navItem:{alignItems:'center',gap:3,minWidth:60},
  navIcon:{fontSize:20,color:C.muted},
  navText:{fontSize:10,color:C.muted},
  navSelected:{color:C.sageDark,fontWeight:'800'},
  focusCard:{backgroundColor:C.pale,borderRadius:22,padding:25,alignItems:'center',gap:12},
  focusLabel:{fontSize:10,fontWeight:'800',letterSpacing:1.5,color:C.sageDark},
  focusTimer:{fontSize:58,fontWeight:'300',letterSpacing:-2,color:C.ink,fontVariant:['tabular-nums']},
  appRow:{flexDirection:'row',alignItems:'center',paddingVertical:12,borderTopWidth:1,borderTopColor:C.line},
  appName:{fontSize:14,fontWeight:'700',color:C.ink},
  appMeta:{fontSize:11,color:C.muted,marginTop:3},
  statusRow:{flexDirection:'row',alignItems:'center',gap:8},
  statusDot:{width:9,height:9,borderRadius:5,backgroundColor:'#C7B8A7'},
  statusDotOn:{backgroundColor:C.sage},
  modalBackdrop:{position:'absolute',top:0,left:0,right:0,bottom:0,backgroundColor:'rgba(31,43,33,0.48)',justifyContent:'center',padding:20},
  pauseCard:{backgroundColor:C.bg,borderRadius:25,padding:24,alignItems:'center',gap:12},
  pauseLeaf:{fontSize:36,color:C.sage},
  pauseTitle:{fontSize:30,fontWeight:'700',color:C.ink},
  bodyCenter:{fontSize:13,color:C.muted,textAlign:'center'},
  countdown:{fontSize:43,fontWeight:'300',color:C.sageDark,marginVertical:3}
});
