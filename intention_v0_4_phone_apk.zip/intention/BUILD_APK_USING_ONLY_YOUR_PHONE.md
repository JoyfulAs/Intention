# Build an Intention APK using only your Android phone

This project does not contain a prebuilt APK. The workflow below builds one in GitHub's cloud, so you do not need a PC, Android Studio, or a local Android SDK.

## What you need
- An Android phone and browser
- A GitHub account
- A repository you control (private is fine)
- GitHub Actions minutes available for the build

## 1. Put the project in GitHub
1. Download and extract `intention_v0_4_phone_apk.zip` on your phone.
2. In your browser, open GitHub and create a **new empty repository** named `intention` (do not add a README or license yet).
3. Open the repository's **Code** menu and create a **Codespace** on the `main` branch.
4. In the Codespaces browser editor, use the file Explorer's upload option to upload the extracted `intention` project folder contents. If folder upload is unavailable on your phone, upload the ZIP file itself into the Codespace, then use the terminal:

   ```bash
   unzip intention_v0_4_phone_apk.zip
   cp -a intention/. .
   rm -rf intention
   ```

5. In the terminal, save the files to GitHub:

   ```bash
   git add .
   git commit -m "Add Intention Android project"
   git push
   ```

   If Git says there is nothing to commit, the files may already be saved.

## 2. Start the cloud APK build
1. Return to the repository on GitHub.
2. Open **Actions**.
3. Select **Build Intention APK** in the left panel.
4. Tap **Run workflow**, keep the `main` branch selected, then tap the green **Run workflow** button.
5. Wait for the run to finish. The first build can take several minutes.
6. Open the completed run and scroll to **Artifacts**.
7. Download `intention-debug-apk`. Extract the downloaded artifact ZIP; inside is `app-debug.apk`.
8. Tap the APK to install it. If Android asks, allow your browser or file manager to install apps from that source. Only install builds from your own repository.

## 3. Enable app detection
1. Open Intention.
2. Go to Settings → Android app detection.
3. Read the disclosure, then open Android Accessibility settings.
4. Manually enable Intention's app-monitor service.
5. Return to Intention and refresh the status.

## Important
- This produces a **debug APK for personal testing**, not a Play Store release.
- Android may show an install warning because the APK is not distributed through Play Protect's usual store flow.
- The app currently detects foreground app changes and stores the latest package. It does **not** block apps or automatically show the pause screen.
- Test on your own device. Accessibility behavior can vary by Android version and phone manufacturer.
- Never enable Accessibility for an app unless you trust its code. Intention's service is designed to observe package transitions only; it does not read screen text, messages, passwords, or keystrokes.
- For public release, configure signing, privacy disclosures, accessibility declarations, and Play policy compliance first. Do not publish this debug APK as a production release.

## If the build fails
Open the failed GitHub Actions run and expand the first red step. The most useful part is usually the last 30–50 lines of that step's log. Keep the full error text; it identifies whether the issue is project generation, package registration, dependency installation, or Android compilation.
