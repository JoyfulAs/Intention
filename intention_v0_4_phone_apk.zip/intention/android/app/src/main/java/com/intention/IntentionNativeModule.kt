package com.intention

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.os.Build
import com.facebook.react.bridge.LifecycleEventListener
import android.provider.Settings
import android.text.TextUtils
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.modules.core.DeviceEventManagerModule

class IntentionNativeModule(
    private val context: ReactApplicationContext
) : ReactContextBaseJavaModule(context), LifecycleEventListener {

    private var receiverRegistered = false
    private val foregroundReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            if (intent?.action != ForegroundMonitorService.ACTION_FOREGROUND_CHANGED) return
            val packageName = intent.getStringExtra(ForegroundMonitorService.EXTRA_PACKAGE) ?: return
            val timestamp = intent.getLongExtra(ForegroundMonitorService.EXTRA_TIME, 0L)
            val payload = Arguments.createMap().apply {
                putString("packageName", packageName)
                putDouble("timestamp", timestamp.toDouble())
            }
            if (context.hasActiveCatalystInstance()) {
                context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                    .emit("IntentionForegroundChanged", payload)
            }
        }
    }

    init {
        context.addLifecycleEventListener(this)
        registerForegroundReceiver()
    }

    override fun getName() = "IntentionNative"

    @ReactMethod
    fun openAccessibilitySettings(promise: Promise) {
        try {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            promise.resolve(true)
        } catch (e: Exception) {
            promise.reject("SETTINGS_ERROR", "Could not open Accessibility settings", e)
        }
    }

    @ReactMethod
    fun isMonitorEnabled(promise: Promise) {
        try {
            val enabled = isServiceEnabled(context, ForegroundMonitorService::class.java)
            promise.resolve(enabled)
        } catch (e: Exception) {
            promise.reject("STATUS_ERROR", "Could not check monitor status", e)
        }
    }

    @ReactMethod
    fun getLatestForegroundApp(promise: Promise) {
        val prefs = context.getSharedPreferences(ForegroundMonitorService.PREFS, Context.MODE_PRIVATE)
        val result = Arguments.createMap()
        result.putString("packageName", prefs.getString(ForegroundMonitorService.KEY_PACKAGE, null))
        result.putDouble("timestamp", prefs.getLong(ForegroundMonitorService.KEY_TIME, 0L).toDouble())
        promise.resolve(result)
    }

    @ReactMethod
    fun addListener(eventName: String) {
        // Required by NativeEventEmitter.
    }

    @ReactMethod
    fun removeListeners(count: Int) {
        // Required by NativeEventEmitter.
    }

    private fun registerForegroundReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter(ForegroundMonitorService.ACTION_FOREGROUND_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) {
            context.registerReceiver(foregroundReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            context.registerReceiver(foregroundReceiver, filter)
        }
        receiverRegistered = true
    }

    private fun unregisterForegroundReceiver() {
        if (!receiverRegistered) return
        try { context.unregisterReceiver(foregroundReceiver) } catch (_: Exception) { }
        receiverRegistered = false
    }

    override fun onHostResume() { registerForegroundReceiver() }
    override fun onHostPause() = Unit
    override fun onHostDestroy() = unregisterForegroundReceiver()

    override fun invalidate() {
        unregisterForegroundReceiver()
        context.removeLifecycleEventListener(this)
        super.invalidate()
    }

    private fun isServiceEnabled(context: Context, serviceClass: Class<*>): Boolean {
        val expected = ComponentName(context, serviceClass)
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        return splitter.any { ComponentName.unflattenFromString(it) == expected }
    }
}
