package com.intention

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.SharedPreferences

/**
 * Observes package transitions only.
 *
 * Privacy boundary:
 * - Never reads AccessibilityNodeInfo text or view contents.
 * - Never records keystrokes, messages, passwords, or screen content.
 * - Stores only the most recent package name and timestamp.
 *
 * This is a detection foundation, not an app blocker.
 */
class ForegroundMonitorService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return
        if (packageName == applicationContext.packageName) return

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        prefs.edit()
            .putString(KEY_PACKAGE, packageName)
            .putLong(KEY_TIME, System.currentTimeMillis())
            .apply()

        // Best-effort event for the React Native process when it is alive.
        sendBroadcast(Intent(ACTION_FOREGROUND_CHANGED).apply {
            setPackage(applicationContext.packageName)
            putExtra(EXTRA_PACKAGE, packageName)
            putExtra(EXTRA_TIME, System.currentTimeMillis())
        })
    }

    override fun onInterrupt() = Unit

    companion object {
        const val PREFS = "intention_monitor"
        const val KEY_PACKAGE = "last_package"
        const val KEY_TIME = "last_time"
        const val ACTION_FOREGROUND_CHANGED = "com.intention.FOREGROUND_CHANGED"
        const val EXTRA_PACKAGE = "package_name"
        const val EXTRA_TIME = "timestamp"
    }
}
