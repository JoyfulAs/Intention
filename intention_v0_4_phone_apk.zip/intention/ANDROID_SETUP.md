# Android detection milestone

## What this adds
- An AccessibilityService configured to receive only window-state changes.
- It stores only the latest foreground package name and timestamp.
- It never reads screen nodes, text, messages, credentials, or keystrokes.
- A React Native native module can open Android Accessibility settings, report whether the service is enabled, read the latest detected package, and forward live package-change events to JavaScript while the app process is alive.

## Important limitation
This is **foreground-app detection only**. It does not yet display an intervention over other apps, enforce budgets in the background, or guarantee detection on every manufacturer/device. The React Native event bridge now forwards package-change broadcasts to JavaScript. The app also reloads the persisted latest event when it returns to the foreground, so events missed while Android suspends the UI can be recovered.

## Integration
1. Copy the Kotlin files into the package matching your Android app namespace. Update `package com.intention` if your namespace differs.
2. Create `android/app/src/main/res/xml/` if it does not exist, then add `intention_accessibility_config.xml`.
3. Merge the service declaration from `AndroidManifest.xml.append` inside the existing `<application>`.
4. Merge the string from `strings.xml.append` into the existing `strings.xml`.
5. Register `IntentionNativePackage()` in `MainApplication.kt` as shown in the snippet.
6. Rebuild the Android app. Native modules cannot be added with Metro refresh alone.
7. In the app, call `IntentionNative.openAccessibilitySettings()`. The user must manually enable Intention in Android Settings.
8. On return, call `IntentionNative.isMonitorEnabled()` and display a clear status.

## React Native example
```tsx
import {IntentionNative} from './src/native/IntentionNative';

async function enableMonitor() {
  await IntentionNative.openAccessibilitySettings();
}

// On screen focus / app resume:
const enabled = await IntentionNative.isMonitorEnabled();
const latest = await IntentionNative.getLatestForegroundApp();
console.log({enabled, latest});
```

## Before a public Play release
- Review the current Google Play Accessibility API policy and declaration requirements.
- Provide prominent in-app disclosure before sending the user to system settings.
- Obtain affirmative user consent.
- Explain exactly what is observed and what is not observed.
- Do not use accessibility to prevent disabling/uninstalling Intention or to bypass Android security controls.
- Validate the API choice with Play policy before investing in overlay/blocking behavior.
- Test on multiple Android versions and OEM devices.

## Current milestone boundaries
- The Settings screen now shows Accessibility status and the latest detected package.
- The Home screen links to the same setup and clearly labels the pause screen as a preview.
- Protected-app switches are still local preferences; detection currently reports package changes but does not yet enforce those preferences.
- No automatic overlay, app blocking, background activity launch, or daily budget enforcement is implemented.

## Device validation checklist
1. Build and install the Android app after registering `IntentionNativePackage()`.
2. Open Settings → Android app detection → Continue to settings.
3. Manually enable Intention's Accessibility service.
4. Return to Intention and confirm the status changes to enabled.
5. Open a few apps, return to Intention, and confirm the latest package is shown.
6. Repeat after force-closing and reopening Intention; confirm the persisted latest package is recovered.
7. Disable the service in Android Settings and confirm the UI reports it as disabled after returning.

Do not describe this as an app blocker until a separate, policy-reviewed intervention mechanism is implemented and tested on physical devices.
