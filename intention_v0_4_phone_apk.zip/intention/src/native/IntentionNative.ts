import {NativeEventEmitter, NativeModules, Platform} from 'react-native';

type ForegroundEvent = {packageName: string; timestamp: number};
type LatestForeground = {packageName: string | null; timestamp: number};
type IntentionNativeAPI = {
  openAccessibilitySettings(): Promise<boolean>;
  isMonitorEnabled(): Promise<boolean>;
  getLatestForegroundApp(): Promise<LatestForeground>;
};

const native = Platform.OS === 'android'
  ? NativeModules.IntentionNative as IntentionNativeAPI | undefined
  : undefined;
const emitter = native ? new NativeEventEmitter(NativeModules.IntentionNative) : null;

export const IntentionNative = {
  available: Boolean(native),
  openAccessibilitySettings: () => native?.openAccessibilitySettings() ?? Promise.reject(new Error('Android native module unavailable')),
  isMonitorEnabled: () => native?.isMonitorEnabled() ?? Promise.resolve(false),
  getLatestForegroundApp: () => native?.getLatestForegroundApp() ?? Promise.resolve({packageName: null, timestamp: 0}),
  subscribe: (listener: (event: ForegroundEvent) => void) => emitter?.addListener('IntentionForegroundChanged', listener) ?? {remove() {}},
};
