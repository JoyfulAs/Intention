from pathlib import Path
import re, shutil

repo = Path(__file__).resolve().parents[1]
project = repo / 'Intention'
if not project.exists():
    raise SystemExit('Expected generated React Native project at ./Intention')
app = project / 'android' / 'app'
java = app / 'src' / 'main' / 'java' / 'com' / 'intention'
res_xml = app / 'src' / 'main' / 'res' / 'xml'
java.mkdir(parents=True, exist_ok=True)
res_xml.mkdir(parents=True, exist_ok=True)

source_java = repo / 'android' / 'app' / 'src' / 'main' / 'java' / 'com' / 'intention'
for name in ['ForegroundMonitorService.kt', 'IntentionNativeModule.kt', 'IntentionNativePackage.kt']:
    shutil.copy2(source_java / name, java / name)
shutil.copy2(repo / 'android' / 'app' / 'src' / 'main' / 'res' / 'xml' / 'intention_accessibility_config.xml', res_xml / 'intention_accessibility_config.xml')

manifest = app / 'src' / 'main' / 'AndroidManifest.xml'
text = manifest.read_text()
if 'com.intention.ForegroundMonitorService' not in text:
    service = '''\n        <service\n            android:name="com.intention.ForegroundMonitorService"\n            android:label="Intention app monitor"\n            android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE"\n            android:exported="true">\n            <intent-filter>\n                <action android:name="android.accessibilityservice.AccessibilityService" />\n            </intent-filter>\n            <meta-data\n                android:name="android.accessibilityservice"\n                android:resource="@xml/intention_accessibility_config" />\n        </service>\n'''
    text = text.replace('</application>', service + '    </application>')
    manifest.write_text(text)

main_app = next((project / 'android' / 'app' / 'src' / 'main' / 'java').rglob('MainApplication.kt'))
text = main_app.read_text()
if 'IntentionNativePackage()' not in text:
    pattern = r'(PackageList\(this\)\.packages\.apply\s*\{)'
    if re.search(pattern, text):
        text = re.sub(pattern, r'\1\n              add(IntentionNativePackage())', text, count=1)
    else:
        pattern = r'(override fun getPackages\(\): List<ReactPackage>\s*\{\s*val packages = PackageList\(this\)\.packages)'
        if re.search(pattern, text):
            text = re.sub(pattern, r'\1\n        packages.add(IntentionNativePackage())', text, count=1)
        else:
            raise RuntimeError('Could not safely locate MainApplication.getPackages(); register IntentionNativePackage() manually.')
    main_app.write_text(text)

print('Android project prepared: native service, manifest, resources, and package registration added.')
