# Intention

A calm, local-first Android-first prototype for opening distracting apps more intentionally.

## Current build
- React Native + TypeScript interface
- Local demo progress using AsyncStorage
- Focus timer, garden, and pause preview
- Android AccessibilityService scaffold that observes foreground package transitions only
- React Native bridge for latest app detection and status
- Manual, user-controlled Accessibility enablement

## Build an APK from a phone
See [BUILD_APK_USING_ONLY_YOUR_PHONE.md](BUILD_APK_USING_ONLY_YOUR_PHONE.md). A GitHub Actions workflow builds a personal-use debug APK in the cloud.

## Current limitations
This is still a prototype. Detection is not app blocking; daily usage budgets are not enforced; the pause screen is only a preview inside Intention. The generated APK must be tested on a physical Android device before relying on detection. Accessibility behavior and Play policy requirements must be reviewed before any public release.
